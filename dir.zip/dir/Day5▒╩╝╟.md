### 一、上堂回顾

#### 1.默写题目

> 1.使用while和for分别实现1~100之间能被3整除的数的和
>
> 2.定义一个元素为数字的列表，将其中的偶数元素输出
>
> 3.使用三种方式遍历2中的列表

#### 2.知识点回顾

> 

### 二、布尔值和空值

#### 1.布尔值

> 一个布尔类型的变量只有两个值：True和False
>
> 作用：用于分支和循环的判断条件
>
> 注意：在分支或者循环中，条件表达式一般使用数值，关系运算符，逻辑运算符
>
> ```Python
> b1 = True
> b2 = False
> print(b1,b2)
>
> print(4 > 5)   #False
> print(1 and  0)  #False
> ```

#### 2.空值

> Python中一种特殊的数据类型，使用None【空值】表示
>
> 注意：区别0,0是数字类型，None本身是一种数据类型
>
> 使用场景：如果一个函数没有返回值，打印函数得到的结果是None
>
> ```Python
> n = None   #面向对象
> ```

### 三、数字类型Number

#### 1.分类

##### 1.1整型

> 在Python中，整型可以处理任意大小的整数【int】
>
> 代码演示：
>
> ```Python
> #1.
> num1 = 10
> num2 = num1
> print(num1,num2)
> print(id(num1),id(num2))
>
> """
> is：比较的是地址
> ==：比较的是内容【值】
> 结论：两个变量的地址相同，则他们的内容相同
>       两个变量的内容相同，则他们的地址不一定相同
> """
>
> #2.可以连续定义多个变量，是同种类型的，初始值特殊相同的
> num1 = num2 = num3 = num4 = 10
>
> #3.同时定义多个变量，初始值不相同
> num1,num2 = 20,30
> print(num1)  #20
> print(num2)  #30
>
> #4.需求：交换两个变量的值
> a = 10
> b = 20
> #方式一：定义中间变量
> temp = a
> a = b
> b = temp
> print("a = %d b = %d" %(a,b))
>
> a = 10
> b = 20
> #方式二：赋值交换
> a,b = b,a  #a = b b = a
> print("a = %d b = %d" %(a,b))
>
> #方式三：加减运算
> a = 10
> b = 20
> a = a + b  #a = 10 + 20
> b = a - b   #30 - 20  = 10
> a = a - b  #30 - 10 = 20
> print("a = %d b = %d" %(a,b))
>
> #方式四：异或运算符
> a = 10
> b = 20
> a = a ^ b   #10 ^ 20
> b = a ^ b   #10  ^ 20  ^ 20  = 10
> a = a ^ b   #10 ^ 20 ^ 10 = 20
> print("a = %d b = %d" %(a,b))
>
> #在实际应用中，使用方式二最多，其次是方式一
> #面试中【交换两个变量的值，不借助于第三方变量】，方式二，方式三和方式四
> ```

##### 1.2浮点型

> 注意：在计算机的底层存储浮点型采用的是科学计数法，运算的时候会四舍五入

##### 1.3复数

> 由实部和虚部组成
>
> 表示形式：a + bj或者complex(a,b)

#### 2.数字类型转换

> 代码演示：
>
> ```Python
> #类型转换
> print(int(1.9))
> print(float(1))
> print(int("123"))
> print(float("123.2"))
>
> #print(int("a123"))
>
> #特殊情况
> #结论：如果将一个字符串转换为整型，要转换成功的，则需要：字符串由数字或者+、-组成，
> # 而且+必须出现在字符串中的第一个字符或者-。此时的+或者-代表的是正负号
> print(int("+123"))
> print(int("-123"))
>
> #print(int("12+3"))
> #print(int("12-3"))
> ```

#### 3.系统的功能

##### 3.1数学功能

> 1>基本用法
>
> abs():求绝对值
>
> max():求最大值
>
> min()：求最小值
>
> pow(n,m):求n的m次方
>
> round(x，n):n是可选的，表示求浮点数x的四舍五入的值，如果给定了n，则表示舍入到小数点后几位
>
> 2>高级用法
>
> 导入math模块
>
> 代码演示：
>
> ```Python
> import math
>
>
> #基本用法：功能名()
> print(abs(-10))
>
> print(max(10,3,6))
> print(min(10,3,6))
>
>
> print(pow(3,5))  #
>
> #n默认为0
> print(round(3.456))  #3
> print(round(3.656))  #4
> print(round(3.456,2))  #3.46
> print(round(3.656,2))   #3.66
>
> #高级用法；math.功能名（）
> #第一步：导入模块  import math
> #a.向上取整：ceil
> print(math.ceil(18.1))
> print(math.ceil(18.9))
>
> #b.向下取整:floor
> print(math.floor(18.1))
> print(math.floor(18.9))
>
> #c.求平方
> print(pow(3,2))
>
> #d.开平方 :sqrt
> #注意：得到的结果是一个浮点型，而且只有正数
> print(math.sqrt(9))
>
>
> #e。获取浮点数的小数部分和整数部分：modf【modify】
> #得到的结果为元组  （小数部分，整数部分）
> print(math.modf(22.3))
> ```

##### 3.2随机数功能

> 代码演示：
>
> ```Python
> import  random
>
> #格式：random.功能（）
>
>
> #1.random.choice(列表)：从指定列表中随机选择一个元素
> list1 = [545,65,57,6]
> num1 = random.choice(list1)
> print(num1)
>
> num2 = random.choice(range(100))  #0~99
>
> num3 = random.choice("hello")   #['h','e',....]
> print(num3)
>
> #需求：产生一个4~10之内的整数随机数
> print(random.choice([4,5,6,7,8,9,10]))
> print(random.choice(range(4,11)))
>
>
> #2.random.randrange():工作原理类似于range的使用
> #生成一个列表，生成一个随机数
> print(random.choice(range(1,100,2)))
> print(random.randrange(1,100,2))  #non-integer step for randrange()")
>
> print(random.randrange(100))
>
> #注意：choice和randrange:生成的随机数都是整数随机数
> ```

##### 3.3三角函数功能【了解】

### 四、元组tuple

#### 1.概述

> 和列表相似，本质上是一种有序的集合
>
> 元组和列表的不同之处：
>
> ​	a.列表:[]  元组：()
>
> ​	b.列表中的元素可以增加和删除的操作，但是，元组中的元素不能随意的更改

#### 2.创建元组

> 创建列表：
>
> ​	空列表：list1 = []
>
> ​	非空列表：list2 = [xx,xx,.....]
>
> 创建元组
>
> ​	空元组:tuple1 = ()
>
> ​	非空元组：tuple2 = (xx,xx,.....)
>
> 代码演示：
>
> ```Python
> #创建空元组
> t1 = ()
> print(t1)
>
> #创建非空元组
> t2 = (12,3,43,5)
> print(t2)
>
> #元组中可以存储不同类型的元素
> t3 = (True,10.2,10,"abc")
> print(t3)
>
> #特殊情况：如果一个元组中只有一个元素,直接书写会被识别为一个基本的数据类型，
> # 为了消除歧义，则需要在第一个元素的后面添加逗号
> t4 = (10,)
> print(t4)
> num1 = 10
> print(num1)
> ```

#### 3.元组元素的访问

> 语法：元组名[索引]，和列表完全相同
>
> 代码演示：
>
> ```Python
> #1.获取值
> tuple1 = (10,20,30,40,50,60)
> print(tuple1[2])
>
> #下标越界
> #print(tuple1[10])  #IndexError: tuple index out of range
>
> print(tuple1[-1])
> print(tuple1[-3])
>
>
> #2.修改值
> #tuple1[2] = 100   #TypeError: 'tuple' object does not support item assignment
>
> tuple2 = (23,43,54,[1,2,3])
> print(tuple2[3][1])
> #修改的是列表中的数据，但是列表的地址并没有发生改变
> tuple2[3][1] = 100
> print(tuple2)
>
> #3.删除元组
> del tuple2
> ```

#### 4.元组的操作

> 代码演示：
>
> ```Python
> #1.组合 +
> t1 = (43,54,65,66)
> t2 = (435,54)
> print(t1 + t2)
>
> #2.重复：  *
> print(t1 * 2)
>
> #3.判断元组是否在元组中；成员运算符
> #in  not in
> print(100 in t1)
> print(100 not in t1)
>
> #4.元组的切片
> t3 = (11,22,33,44,55,66,77)
> print(t3[2:4])
> print(t3[2:])
> print(t3[:4])
> print(t3[1:4:2])
> print(t3[::-1])
> ```

#### 5.元组的功能

> 代码演示：
>
> ```Python
> #1.获取元组的元素个数
> t1 = (3,54,6,6,565)
> print(len(t1))
>
>
> #2.获取元组中的最大值和最小值
> print(max(t1))
> print(min(t1))
>
>
> #3.元组和列表之间进行相互转换：取长补短
> #3.1  元组------》列表   list()
> list1 = list(t1)
> print(list1)
>
> #3.2列表-----》元组    tuple()
> tuple1 = tuple(list1)
> print(tuple1)
>
> #注意：在命名变量的时候，尽量不要使用系统的函数名
> list = []
> #list2 = list(t1)
> #print(list2)
>
> #4.遍历元组
> #4.1遍历元素
> for i in t1:
>     print(i)
>
> #4.2遍历索引
> for j in range(len(t1)):
>     print(t1[j])
>
> #4.3遍历索引和元素
> for index,element in enumerate(t1):
>     print(index,element)
> ```

#### 6.二维元组

> 跟二维列表类似，表示一个元组中的元素仍然是一个元组
>
> 代码演示：
>
> ```Python
> #二维元组
> tuple1 = ((2,43,34),("hello","abc"),(True,27,438))
> #while
> i = 0   #外层元组的索引
> while i <= len(tuple1) - 1:
>     #tuple1[i]
>     j = 0  # 内层元组的索引
>     while j < len(tuple1[i]):
>         print(tuple1[i][j])
>         j += 1
>     i += 1
>
>
> #for
> for e1 in tuple1:
>     for e2 in e1:
>         print(e2)
> ```

#### 7.总结

> 问题：已经有了列表这种数据结构，为什么还有元组
>
> a.元组中的元素无法修改【多线程】，如果不需要对数据进行增加删除以及替换的操作，可以考虑使用元素；如果需要对数据进行增加删除以及替换的操作，只能使用列表
>
> b.元组在创建时间和占用空间上都优于列表

### 五、字典dict【掌握】

#### 1.概述

> 思考问题：存储5个人的年龄
>
> ```Python
> list1 = [10,3,4,15,54]
> tuple1 = (10,3,4,15,54)
> #缺点：数据容易发生混乱
> #二维列表或者二维元组解决
> list2 = [["xiaoming",10],["jack",3],["bob",4]]
> #缺点：比较麻烦，要取出具体的数据必须要经历嵌套循环遍历
> ```
>
> 解决方案：可以采用字典，将人的姓名作为key，年龄作为value进行存储【实际上存储的是键值对】，方便查找
>
> 本质：也是一种存储数据的方式，但是字典是无序的
>
> 优点：具有极快的查找速度

#### 2.key的特性

> 1》key在字典中是唯一的【后出现的key会将之前出现的key覆盖掉】
>
> 2》key必须是不可变的数据
>
> ​	list是可变的，不能充当key
>
> ​	tuple，整型，字符串都是不可变的，可以充当key

#### 3.字典的创建

> 语法：字典名 = {key1:value1,key2:value2......}
>
> 代码演示：
>
> ```Python
> 1.创建
> #创建空字典
> dict1 = {}
> print(dict1)
>
> #创建非空字典
> dict2 = {"zhangsan":10,"jack":5,"bob":18}
> print(dict2)
> ```

#### 4.元素的访问

> 代码演示：
>
> ```Python
> #2.字典中元素的访问
> #注意：在list和tuple中通过索引访问元素，但是字典是无序的，所以不能使用索引，使用key
> #2.1获取；字典名[key]
> #通过key获取对应的value
> age1 = dict2["jack"]
> print(age1)
>
> #方式一
> #如果key不存在，则报KeyError
> #age2 = dict2["lisi"]   #KeyError: 'lisi'
> #print(age2)
>
> #方式二
> #如果key不存在，则返回None,常用于条件判断
> age2 = dict2.get("lisi")
> print(age2)   #None
> if age2 == None:
>     print("不存在")
> else:
>     print("存在")
>
> #2.2添加和修改
> print(dict2)
> #如果key不存在，则表示添加
> dict2["tom"] = 22
> print(dict2)
> #如果key存在，则表示修改
> dict2["jack"] = 66
> print(dict2)
>
> #3。删除
> #删除键值对；通过删除key删除键值对
> dict2.pop("jack")
> print(dict2)
>
> #删除字典
> del dict2
> ```

#### 5.字典的遍历

> 代码演示：
>
> ```Python
> #字典的遍历
> dict1 = {"zhangsan":10,"jack":5,"bob":18}
> #1.只获取key
> for key in dict1:
>     print("%s = %d" %(key,dict1[key]))
>
> #2.只获取key:keys()
> print(dict1.keys())
> for key in dict1.keys():
>     print("%s = %d" % (key, dict1[key]))
>
> #3.只获取value：values()  【了解】
> for value in dict1.values():
>     print(value)
>
> #4.通过枚举获取key
> for index,key  in enumerate(dict1):
>     print(index,key)
>     print("%s = %d" % (key, dict1[key]))
>
> #5.同时获取key和value：items()
> print(dict1.items())
> for key,value in dict1.items():
>     print("%s = %d" % (key, value))
> ```

#### 6.和list的区别

> a.字典查找和插入的速度都是比较快的，不会随着key-value的增加而变慢；但是，list在查找的时候需要从前向后挨个遍历元素，如果数据量大的情况下，速度会随着减慢
>
> b.字典需要占用大量的内存，内存浪费多，但是，list相当于只存储了key或者只存储了value，数据是紧密排列的

#### 7.练习

> ```Python
> #1.自定义一个字典，逐一显示字典中的所有键，并在显示之后输出总的键值对
> dict1 = {}
> #方式一
> count1 = 0
> for key in dict1:
>     print(key)
>     count1 += 1
>
> print(count1)
>
> #方式二
> for key in dict1:
>     print(key)
> else:
>     print(len(dict1))
>
>
> #2.以l1中的元素作为key，以l2中的元素作为value，生成一个字典dict1
> l1 = [0,1,2,3,4,5,6]
> l2 = ["Sun","Mon","Tue","Wed","Thur","Fri","Sat"]
> dict1 = {}
> #{0：“Sun”,1:"Mon"...}
>
> #方式一：for
> for i in range(len(l1)):
>     dict1[l1[i]] = l2[i]
> print(dict1)
>
>
> dict1 = {}
> #方式二
> #定义一个变量,作为l1和l2的索引
> index = 0
>
> if len(l1) <= len(l2):
>     while index < len(l1):
>         dict1[l1[index]] = l2[index]
>         index += 1
> #如果两个列表的长度不相等，则需要以短的列表作为参照物，否则会出现索引越界
> elif len(l1) > len(l2):
>     while index < len(l2):
>         dict1[l1[index]] = l2[index]
>         index += 1
>
> print(dict1)
> ```